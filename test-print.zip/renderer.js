// This file is required by the index.html file and will
// be executed in the renderer process for that window.
// No Node.js APIs are available in this process because
// `nodeIntegration` is turned off. Use `preload.js` to
// selectively enable features needed in the rendering
// process.

const { remote } = require("electron")
const path = require("path")
const os = require("os")
const fs = require("fs")
const { BrowserWindow } = remote

var btn = document.getElementById("current")
const options = {
	silent: true,
	deviceName: "FIT FP-2000 Raster",
	color: false,
	collate: false,
	pageSize: "Letter",
	margins: {
		marginType: "custom",
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
	},
	printBackground: false,
	printSelectionOnly: false,
}

btn.addEventListener("click", (event) => {
	let win = new BrowserWindow({
		width: 500,
		height: 600,
		// show: false,
	})

	win.loadFile("print.html")
	// win.loadURL(path.join(os.homedir(), "Desktop", "temp.pdf"))

	win.webContents.on("did-finish-load", function () {
		// const pdfPath = path.join(os.homedir(), "Desktop", "temp.pdf")
		// win.webContents
		//   .printToPDF({
		//     marginsType: 0,
		//     printBackground: false,
		//     printSelectionOnly: false,
		//     landscape: false,
		//     pageSize: "Letter",
		//     scaleFactor: 100,
		//   })
		//   .then((data) => {
		//     fs.writeFile(pdfPath, data, (error) => {
		//       if (error) throw error
		//       console.log(`Wrote PDF successfully to ${pdfPath}`)
		//     })
		//   })
		//   .catch((error) => {
		//     console.log(`Failed to write PDF to ${pdfPath}: `, error)
		//   })
		win.webContents.print(options, (success, failureReason) => {
			if (!success) console.log(failureReason)
			win.close()
			console.log("Print Initiated")
		})
	})
	// win.loadURL("http://202.80.234.74/app/kiosk/print?que_ids=631798")

	// setTimeout(() => {
	//   win.webContents.print(options, (success, failureReason) => {
	//     if (!success) console.log(failureReason)

	//     console.log("Print Initiated")
	//   })
	// }, 300)
})
